# online_english_system

#### 介绍
基于springboot+vue的英语在线学习平台的设计与实现

#### 软件架构
软件架构说明


#### 安装教程

1.  npm install
2.  npm run dev

#### 用户端
![alt text](back_imgs/image.png)
![alt text](back_imgs/image-1.png)

![alt text](back_imgs/image-2.png)
![alt text](back_imgs/image-3.png)

![alt text](back_imgs/image-4.png)
![alt text](back_imgs/image-5.png)
![alt text](back_imgs/image-6.png)

![alt text](back_imgs/image-7.png)
![alt text](back_imgs/image-8.png)
![alt text](back_imgs/image-9.png)
![alt text](back_imgs/image-10.png)

![alt text](back_imgs/image-11.png)
![alt text](back_imgs/image-12.png)

![alt text](back_imgs/image-13.png)
![alt text](back_imgs/image-14.png)
![alt text](back_imgs/image-15.png)
![alt text](back_imgs/image-16.png)

#### 管理端
![alt text](back_imgs/image-32.png)
![alt text](back_imgs/image-17.png)
![alt text](back_imgs/image-18.png)
![alt text](back_imgs/image-19.png)
![alt text](back_imgs/image-20.png)
![alt text](back_imgs/image-21.png)
![alt text](back_imgs/image-22.png)
![alt text](back_imgs/image-23.png)
![alt text](back_imgs/image-24.png)
![alt text](back_imgs/image-25.png)
![alt text](back_imgs/image-26.png)
![alt text](back_imgs/image-27.png)
![alt text](back_imgs/image-28.png)
![alt text](back_imgs/image-29.png)
![alt text](back_imgs/image-30.png)
![alt text](back_imgs/image-31.png)