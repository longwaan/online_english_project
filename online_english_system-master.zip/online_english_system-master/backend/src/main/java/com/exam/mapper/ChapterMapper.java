package com.exam.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.exam.model.entity.Chapter;

public interface ChapterMapper extends BaseMapper<Chapter> {

} 