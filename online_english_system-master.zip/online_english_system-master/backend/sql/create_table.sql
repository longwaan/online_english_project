SET NAMES utf8mb4;
SET
FOREIGN_KEY_CHECKS = 0;


-- 章节表
DROP TABLE IF EXISTS `chapter`;
CREATE TABLE `chapter`
(
    `id`         bigint                                                        NOT NULL AUTO_INCREMENT COMMENT '章节ID',
    `courseId`   bigint                                                        NOT NULL COMMENT '所属课程ID',
    `title`      varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '章节标题',
    `content`    text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '章节内容',
    `createTime` datetime                                                      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updateTime` datetime                                                      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `coverImage` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '章节封面图片',
    `videoUrl`   varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '章节视频链接',
    `duration`   int NULL DEFAULT NULL COMMENT '章节视频时长（秒）',
    PRIMARY KEY (`id`) USING BTREE,
    INDEX        `courseId`(`courseId` ASC) USING BTREE,
    CONSTRAINT `chapter_ibfk_1` FOREIGN KEY (`courseId`) REFERENCES `course` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '章节表' ROW_FORMAT = Dynamic;


-- 课程表
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course`
(
    `id`          bigint                                                        NOT NULL AUTO_INCREMENT COMMENT '课程ID',
    `title`       varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '课程标题',
    `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '课程描述',
    `createTime`  datetime                                                      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updateTime`  datetime                                                      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `coverImage`  varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '课程封面图片',
    `level`       varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '课程等级：简单 中级 高级',
    `status`      int NOT NULL DEFAULT '0' COMMENT '课程状态：0-未上线 1-上线',
    PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '课程表' ROW_FORMAT = Dynamic;


-- 试卷表
DROP TABLE IF EXISTS `exam`;
CREATE TABLE `exam`
(
    `id`          bigint                                                        NOT NULL AUTO_INCREMENT COMMENT '试卷ID',
    `title`       varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '试卷标题',
    `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '试卷描述',
    `totalScore`  int                                                           NOT NULL DEFAULT 100 COMMENT '总分',
    `createTime`  datetime                                                      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updateTime`  datetime                                                      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `startTime`   datetime NULL DEFAULT NULL COMMENT '试卷开始时间',
    `endTime`     datetime NULL DEFAULT NULL COMMENT '试卷结束时间',
    PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '试卷表' ROW_FORMAT = Dynamic;


-- 帖子
DROP TABLE IF EXISTS `post`;
CREATE TABLE `post`
(
    `id`         bigint   NOT NULL AUTO_INCREMENT COMMENT 'id',
    `title`      varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '标题',
    `content`    text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '内容',
    `tags`       varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '标签列表（json 数组）',
    `thumbNum`   int      NOT NULL DEFAULT 0 COMMENT '点赞数',
    `favourNum`  int      NOT NULL DEFAULT 0 COMMENT '收藏数',
    `userId`     bigint   NOT NULL COMMENT '创建用户 id',
    `createTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `isDelete`   tinyint  NOT NULL DEFAULT 0 COMMENT '是否删除',
    PRIMARY KEY (`id`) USING BTREE,
    INDEX        `idx_userId`(`userId` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '帖子' ROW_FORMAT = Dynamic;


-- 帖子评论表
DROP TABLE IF EXISTS `post_comment`;
CREATE TABLE `post_comment`
(
    `id`         bigint   NOT NULL AUTO_INCREMENT COMMENT 'id',
    `postId`     bigint   NOT NULL COMMENT '帖子 id',
    `userId`     bigint   NOT NULL COMMENT '评论用户 id',
    `content`    text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '评论内容',
    `createTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `isDelete`   tinyint  NOT NULL DEFAULT 0 COMMENT '是否删除',
    `replyTo`    bigint NULL DEFAULT NULL COMMENT '回复的评论ID',
    `likes`      int NULL DEFAULT 0 COMMENT '评论点赞数',
    PRIMARY KEY (`id`) USING BTREE,
    INDEX        `idx_postId`(`postId` ASC) USING BTREE,
    INDEX        `idx_userId`(`userId` ASC) USING BTREE,
    CONSTRAINT `post_comment_ibfk_1` FOREIGN KEY (`postId`) REFERENCES `post` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '帖子评论表' ROW_FORMAT = Dynamic;


-- 帖子收藏
DROP TABLE IF EXISTS `post_favour`;
CREATE TABLE `post_favour`
(
    `id`         bigint   NOT NULL AUTO_INCREMENT COMMENT 'id',
    `postId`     bigint   NOT NULL COMMENT '帖子 id',
    `userId`     bigint   NOT NULL COMMENT '创建用户 id',
    `createTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`) USING BTREE,
    INDEX        `idx_postId`(`postId` ASC) USING BTREE,
    INDEX        `idx_userId`(`userId` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin COMMENT = '帖子收藏' ROW_FORMAT = Dynamic;


-- 帖子点赞
DROP TABLE IF EXISTS `post_thumb`;
CREATE TABLE `post_thumb`
(
    `id`         bigint   NOT NULL AUTO_INCREMENT COMMENT 'id',
    `postId`     bigint   NOT NULL COMMENT '帖子 id',
    `userId`     bigint   NOT NULL COMMENT '创建用户 id',
    `createTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`) USING BTREE,
    INDEX        `idx_postId`(`postId` ASC) USING BTREE,
    INDEX        `idx_userId`(`userId` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin COMMENT = '帖子点赞' ROW_FORMAT = Dynamic;


-- 试卷题目表
DROP TABLE IF EXISTS `question`;
CREATE TABLE `question`
(
    `id`              bigint   NOT NULL AUTO_INCREMENT COMMENT '题目ID',
    `examId`          bigint   NOT NULL COMMENT '所属试卷ID',
    `questionType`    enum('单选','多选','判断','填空','简答') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '题目类型',
    `questionText`    text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '题目内容',
    `options`         text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '选项（JSON格式）',
    `correctAnswer`   text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '正确答案',
    `score`           int      NOT NULL DEFAULT 5 COMMENT '该题分值',
    `createTime`      datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updateTime`      datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `difficultyLevel` enum('简单','中等','困难') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '简单' COMMENT '题目难度级别',
    `explanation`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '题目解析',
    PRIMARY KEY (`id`) USING BTREE,
    INDEX             `examId`(`examId` ASC) USING BTREE,
    CONSTRAINT `question_ibfk_1` FOREIGN KEY (`examId`) REFERENCES `exam` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '试卷题目表' ROW_FORMAT = Dynamic;


-- 学习记录表
DROP TABLE IF EXISTS `study_record`;
CREATE TABLE `study_record`
(
    `id`         bigint   NOT NULL AUTO_INCREMENT COMMENT '学习记录ID',
    `userId`     bigint   NOT NULL COMMENT '用户ID',
    `courseId`   bigint NULL DEFAULT NULL COMMENT '课程ID',
    `examId`     bigint NULL DEFAULT NULL COMMENT '试卷ID',
    `progress`   int      NOT NULL DEFAULT 0 COMMENT '学习进度（%）',
    `status`     enum('进行中','已完成') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '进行中' COMMENT '状态',
    `createTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `studyTime`  int NULL DEFAULT NULL COMMENT '学习时长（分钟）',
    `score`      float NULL DEFAULT NULL COMMENT '得分',
    PRIMARY KEY (`id`) USING BTREE,
    INDEX        `userId`(`userId` ASC) USING BTREE,
    CONSTRAINT `study_record_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '学习记录表' ROW_FORMAT = Dynamic;

-- 用户表
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`
(
    `id`           bigint                                                        NOT NULL AUTO_INCREMENT COMMENT 'id',
    `userAccount`  varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '账号',
    `userPassword` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '密码',
    `unionId`      varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '微信开放平台id',
    `mpOpenId`     varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '公众号openId',
    `userName`     varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户昵称',
    `userAvatar`   varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户头像',
    `userProfile`  varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户简介',
    `userRole`     varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user' COMMENT '用户角色：user/admin/ban',
    `createTime`   datetime                                                      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updateTime`   datetime                                                      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `isDelete`     tinyint                                                       NOT NULL DEFAULT 0 COMMENT '是否删除',
    PRIMARY KEY (`id`) USING BTREE,
    INDEX          `idx_unionId`(`unionId` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1901885819174555651 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '用户' ROW_FORMAT = Dynamic;


-- 用户课程关系表
DROP TABLE IF EXISTS `user_course`;
CREATE TABLE `user_course`
(
    `id`             bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `userId`         bigint NOT NULL COMMENT '用户ID',
    `courseId`       bigint NOT NULL COMMENT '课程ID',
    `role`           enum('学习者','讲师','管理员') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '学习者' COMMENT '用户在该课程中的角色',
    `enrollmentTime` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '加入时间',
    PRIMARY KEY (`id`) USING BTREE,
    INDEX            `userId`(`userId` ASC) USING BTREE,
    INDEX            `courseId`(`courseId` ASC) USING BTREE,
    CONSTRAINT `user_course_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
    CONSTRAINT `user_course_ibfk_2` FOREIGN KEY (`courseId`) REFERENCES `course` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '用户课程关系表' ROW_FORMAT = Dynamic;


-- 词汇表
DROP TABLE IF EXISTS `vocabulary`;
CREATE TABLE `vocabulary`
(
    `id`              bigint                                                        NOT NULL AUTO_INCREMENT COMMENT '词汇ID',
    `word`            varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '单词',
    `phonetic`        varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '音标',
    `meaning`         text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '词义',
    `example`         text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '例句',
    `createTime`      datetime                                                      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `difficultyLevel` enum('初级','中级','高级') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '初级' COMMENT '词汇难度级别',
    `isPhrase`        enum('单词','词组') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '单词' COMMENT '表示该条记录是单词还是词组',
    PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 118 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '词汇表' ROW_FORMAT = Dynamic;

SET
FOREIGN_KEY_CHECKS = 1;
