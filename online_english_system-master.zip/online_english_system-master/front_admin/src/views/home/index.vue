<script setup lang="ts">
</script>

<template>
    <div>
        <h1>首页</h1>
    </div>
</template>
