<template>
  <div class="error-page">
    <h1>404</h1>
    <p>抱歉，页面不存在</p>
  </div>
</template>

<style scoped>
.error-page {
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #f5f7fa;
}
</style> 